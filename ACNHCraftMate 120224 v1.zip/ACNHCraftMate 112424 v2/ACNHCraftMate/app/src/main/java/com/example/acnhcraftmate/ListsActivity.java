package com.example.acnhcraftmate;

import android.os.Bundle;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import android.view.View;
import android.widget.Button;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Toast;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.widget.EditText;


public class ListsActivity extends AppCompatActivity {
    private RadioGroup radioGroupLists;
    private int listCounter = 1;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_lists);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.btn_open_lists), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        Button btnNewList = findViewById(R.id.btnNewList);
        Button btnDeleteList = findViewById(R.id.btnDelete);
        Button btnCopyList = findViewById(R.id.btnCopy);
        radioGroupLists = findViewById(R.id.radio_group_lists);
        Button btnRenameList = findViewById(R.id.btn_rename_list);
        Button btnOpenList = findViewById(R.id.btn_open_lists);


        btnNewList.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                addNewList();
            }
        });


        btnDeleteList.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                deleteSelectedList();
            }
        });


        btnCopyList.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                copySelectedList();
            }
        });


        btnRenameList.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                renameSelectedList();
            }
        });


        btnOpenList.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openSelectedList();
            }
        });
    }

    private void addNewList() {
        RadioButton newRadioButton = new RadioButton(this);
        newRadioButton.setText("List " + listCounter);
        newRadioButton.setId(View.generateViewId());
        radioGroupLists.addView(newRadioButton);
        listCounter++;
        Toast.makeText(this, "New list created!", Toast.LENGTH_SHORT).show();
    }

    private void deleteSelectedList() {
        int selectedId = radioGroupLists.getCheckedRadioButtonId();
        if (selectedId != -1) {
            View selectedRadioButton = findViewById(selectedId);
            radioGroupLists.removeView(selectedRadioButton);
            Toast.makeText(this, "List deleted!", Toast.LENGTH_SHORT).show();
        } else {
            Toast.makeText(this, "Please select a list to delete.", Toast.LENGTH_SHORT).show();
        }
    }

    private void copySelectedList() {
        int selectedId = radioGroupLists.getCheckedRadioButtonId();
        if (selectedId != -1) {
            RadioButton selectedRadioButton = findViewById(selectedId);
            RadioButton copiedRadioButton = new RadioButton(this);
            copiedRadioButton.setText(selectedRadioButton.getText() + " (Copy)");
            copiedRadioButton.setId(View.generateViewId());
            radioGroupLists.addView(copiedRadioButton);
            Toast.makeText(this, "List copied!", Toast.LENGTH_SHORT).show();
        } else {
            Toast.makeText(this, "Please select a list to copy.", Toast.LENGTH_SHORT).show();
        }
    }

    private void renameSelectedList() {
        int selectedId = radioGroupLists.getCheckedRadioButtonId();
        if (selectedId != -1) {
            RadioButton selectedRadioButton = findViewById(selectedId);


            AlertDialog.Builder builder = new AlertDialog.Builder(this);
            builder.setTitle("Rename List");


            final EditText input = new EditText(this);
            input.setText(selectedRadioButton.getText());
            builder.setView(input);


            builder.setPositiveButton("Save", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {
                    selectedRadioButton.setText(input.getText().toString());
                    Toast.makeText(ListsActivity.this, "List renamed!", Toast.LENGTH_SHORT).show();
                }
            });
            builder.setNegativeButton("Cancel", null);

            builder.show();
        } else {
            Toast.makeText(this, "Please select a list to rename.", Toast.LENGTH_SHORT).show();
        }
    }

    private void openSelectedList() {
        int selectedId = radioGroupLists.getCheckedRadioButtonId();
        if (selectedId != -1) {
            RadioButton selectedRadioButton = findViewById(selectedId);
            Intent intent = new Intent(this, DetailedListActivity.class);
            intent.putExtra("listName", selectedRadioButton.getText().toString());
            startActivity(intent);
        } else {
            Toast.makeText(this, "Please select a list to open.", Toast.LENGTH_SHORT).show();
        }
    }
}