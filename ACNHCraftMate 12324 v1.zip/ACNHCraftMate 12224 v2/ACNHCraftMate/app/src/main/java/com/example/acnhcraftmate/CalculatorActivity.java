package com.example.acnhcraftmate;

import android.content.Intent;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;
import android.util.Log;

import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;


import android.view.inputmethod.InputMethodManager;


public class CalculatorActivity extends AppCompatActivity {
    private Button search, CalcList, mainMenu;
    private EditText searchText;
    private ListView listView;

    private DBHelper myDbHelper;
    private SQLiteDatabase db;
    public ArrayList<String> itemList, calcItemsArray;
    private ArrayAdapter<String> adapter;


    //array of all the DIY items we want to make
    public ArrayList<String> recipeNameList;
    //array of all the ingredients associated with the DIY recipes
    public ArrayList<String> RIngredientsList;

    //array of all the quantities needed for each ingredient in the recipe
    public ArrayList<Integer> IngQuantityList;

    private int i = 0;

    Intent DetailedListActivity;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_calculator);

        // Initialize views
        search = findViewById(R.id.search);
        searchText = findViewById(R.id.searchText);
        listView = findViewById(R.id.listView);
        CalcList = findViewById(R.id.toCalcList);
        mainMenu = findViewById(R.id.menuButtonCalc);

        // Initialize the database
        myDbHelper = new DBHelper(this);
        myDbHelper.createDatabase(); // Ensure DB is created and copied from assets
        db = myDbHelper.getWritableDatabase();

        // Load all data initially
        loadData("");

        // Set up the search button
        search.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String query = searchText.getText().toString().trim();
                loadData(query); // Search the database with the query
            }
        });

        mainMenu.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v){
                Intent intent = new Intent(CalculatorActivity.this, MainActivity.class);
                startActivity(intent);
            }
        });

        // Handle list item clicks
        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                String selectedItem = itemList.get(position);
                Toast.makeText(CalculatorActivity.this, "Selected: " + selectedItem, Toast.LENGTH_SHORT).show();

                //get intent, pass extra to view
//                Intent intent = new Intent("com.example.newactivity");
//                intent.putExtra("list_position", arg2);
//                startActivity(intent);

                Intent intent = new Intent("com.example.calclistactivity");
                intent.putExtra("test", selectedItem);

            }
        });

        CalcList.setOnClickListener(new View.OnClickListener()
        { @Override
            public void onClick(View view) {
            //send to CalcList Activity

            Toast.makeText(CalculatorActivity.this, "clicked on calc list button", Toast.LENGTH_SHORT).show();
            Intent intent = new Intent(CalculatorActivity.this, CalcListActivity.class);

            Toast.makeText(CalculatorActivity.this, "created Intent", Toast.LENGTH_SHORT).show();

            //crashes here, maybe because there is no data to display in the ListView?
            startActivity(intent);

            Toast.makeText(CalculatorActivity.this, "started Intent", Toast.LENGTH_SHORT).show();

            }


        });
    }

    /**
     * Loads data from the database and displays it in the list view.
     *
     * @param searchQuery The search query to filter results (empty string for all results).
     */
    private void loadData(String searchQuery) {
        itemList = new ArrayList<>();
        Cursor cursor = null;

        try {
            // Query for all items if no search query is provided
            if (searchQuery.isEmpty()) {
                cursor = db.rawQuery("SELECT * FROM CraftTable", null);
            } else {
                // Query based on the search query
                cursor = db.rawQuery("SELECT * FROM CraftTable WHERE ItemName LIKE ?", new String[]{"%" + searchQuery + "%"});
            }

            if (cursor != null && cursor.moveToFirst()) {
                do {
                    // Log column names to check if they're correctly retrieved
                    String[] columnNames = cursor.getColumnNames();
                    for (String columnName : columnNames) {
                        Log.d("Database", "Column Name: " + columnName);
                    }

                    // Get the "ItemName" from the cursor
                    int itemNameColumnIndex = cursor.getColumnIndex("ItemName");
                    if (itemNameColumnIndex >= 0) {
                        String itemName = cursor.getString(itemNameColumnIndex);
                        itemList.add(itemName);
                    }
                } while (cursor.moveToNext());
                cursor.close();
            }

            // Update the ListView with the fetched data
            adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, itemList);
            listView.setAdapter(adapter);

        } catch (SQLException e) {
            Toast.makeText(this, "Error loading data: " + e.getMessage(), Toast.LENGTH_SHORT).show();
        } finally {
            if (cursor != null && !cursor.isClosed()) {
                cursor.close();
            }
        }
    }

    /**
     * Hides the soft keyboard.
     */
    public void hideSoftKeyboard() {
        if (getCurrentFocus() != null) {
            InputMethodManager inputMethodManager = (InputMethodManager) getSystemService(INPUT_METHOD_SERVICE);
            inputMethodManager.hideSoftInputFromWindow(getCurrentFocus().getWindowToken(), 0);
        }
    }

//    public void setCalcItemsArray(ArrayList<String> calcItemsArray) {
//        this.calcItemsArray = calcItemsArray;
//    }
}