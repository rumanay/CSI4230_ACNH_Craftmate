package com.example.acnhcraftmate;


import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;

public class DBHelper extends SQLiteOpenHelper {
    private static final String DATABASE_NAME = "ACNHrecipe.db"; // Your database file name
    private static final String DATABASE_PATH = "/data/data/com.example.acnhcraftmate/databases/";
    private static final int DATABASE_VERSION = 1; // Update this version if the database schema changes
    private final Context context;

    public DBHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
        this.context = context;
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        // Not used for a pre-populated database
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        // Handle database upgrades if needed
    }

    /**
     * Checks if the database file already exists in the application's data directory.
     */
    private boolean checkDatabaseExists() {
        File databaseFile = new File(DATABASE_PATH + DATABASE_NAME);
        return databaseFile.exists();
    }

    /**
     * Copies the database from the assets folder to the app's database directory.
     */
    private void copyDatabase() throws Exception {
        InputStream input = context.getAssets().open(DATABASE_NAME); // Access database from assets
        String outFileName = DATABASE_PATH + DATABASE_NAME; // Where the database will be copied
        File databaseFolder = new File(DATABASE_PATH);

        // Ensure the databases folder exists
        if (!databaseFolder.exists()) {
            databaseFolder.mkdirs();
        }

        OutputStream output = new FileOutputStream(outFileName);

        byte[] buffer = new byte[1024];
        int length;
        while ((length = input.read(buffer)) > 0) {
            output.write(buffer, 0, length);
        }

        output.flush();
        output.close();
        input.close();
    }

    /**
     * Creates the database if it doesn't already exist.
     */
    public void createDatabase() {
        if (!checkDatabaseExists()) {
            this.getReadableDatabase(); // Creates an empty database file
            this.close(); // Close the empty database to overwrite it
            try {
                copyDatabase(); // Copies the pre-populated database from assets
            } catch (Exception e) {
                throw new RuntimeException("Error copying database: " + e.getMessage());
            }
        }
    }

    /**
     * Opens the database for use.
     */
    public SQLiteDatabase openDatabase() {
        String path = DATABASE_PATH + DATABASE_NAME;
        return SQLiteDatabase.openDatabase(path, null, SQLiteDatabase.OPEN_READWRITE);
    }
}
