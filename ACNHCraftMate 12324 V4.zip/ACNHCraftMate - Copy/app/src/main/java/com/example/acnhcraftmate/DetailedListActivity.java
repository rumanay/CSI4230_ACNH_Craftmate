package com.example.acnhcraftmate;

import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import java.util.ArrayList;

public class DetailedListActivity extends AppCompatActivity {

    private ListView listView;
    private Button addButton;
    private DBHelper myDbHelper;
    private SQLiteDatabase db;
    private ArrayList<String> itemList;
    private ArrayAdapter<String> adapter;

    Intent addtoCalcList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detailed_lists);

        myDbHelper = new DBHelper(this);
        myDbHelper.createDatabase(); // Ensure DB is created and copied from assets
        db = myDbHelper.getWritableDatabase();

        addButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //add item to list
                //query recipeTable to get copy all columns over to new table
                //add new column for "copies" ex: 4 Flimsy Axes would have the normal columns but have one more
                // column showing the total copies wanting to be made for that item
                // that way we can just multiply the quantity in each IngQuantity field by the copies column



            }
                                     }

        );
        EdgeToEdge.enable(this);

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
    }
}