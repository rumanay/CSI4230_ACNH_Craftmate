package com.example.acnhcraftmate;

import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import android.content.Intent;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    //create Java objects
    //DBHelper myDbHelper;
    Button btnCalculator, btnLists;
    //create java Database Object
    public static SQLiteDatabase db;
    //text to search in database
    EditText searchText;
    //placeholder text
    String txt ="";

    //open textview that says the item searched was not found
    TextView noResults;


    //arrays to capture each craftable item's list of ingredients,
    // name of ingredients and quantity of each ingredient
    ArrayList<String> IngredientNames;
    ArrayList<Integer> IngredientIDs;
    ArrayList<Integer> IngredientQuantites;

    //three individual arrays to combine all requirements into one "view"
    String[] allIngredients; //store all ingridient names
    Integer[] allIngIDs; //store all ingredient IDs
    Integer[] allIngQuantities; //store all ingredient quantities

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);


        //associate XML objects to Java code

        //button to go to Calculator View
        btnCalculator = findViewById(R.id.btn_calculator);
        //button to go to Lists View
        btnLists = findViewById(R.id.btn_lists);

        //
        //createDB();
       // Toast.makeText(CalculatorActivity.this, "added to list: " + selectedItem, Toast.LENGTH_SHORT).show();



        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.constraint123), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });



        //move user to Calculator Activity View
        btnCalculator.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, CalculatorActivity.class);
                startActivity(intent);
            }
        });

        //Move User to Lists Activity View
        btnLists.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, ListsActivity.class);
                startActivity(intent);
            }
        });
    }//end ON CREATE

}