package com.example.acnhcraftmate;

import android.content.Intent;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;

public class CalcListActivity extends AppCompatActivity {

    ListView calcListJ;
    Button back, results;
    private DBHelper myDbHelper;
    private SQLiteDatabase db;
    private ArrayAdapter<String> adapter;
    private ArrayList<String> itemList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_calclist);

        calcListJ = findViewById(R.id.calcList);
        back = findViewById(R.id.backButton);
        results = findViewById(R.id.tempresultsButton);

        // Initialize DB
        myDbHelper = new DBHelper(this);
        myDbHelper.createDatabase();
        db = myDbHelper.getWritableDatabase();

        // Retrieve selected items from Intent
        ArrayList<String> selectedItems = getIntent().getStringArrayListExtra("selectedItems");

        // Load data from CalcList table for selected items
        loadCalcListTable(selectedItems);

        // Set up adapter
        adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, itemList);
        calcListJ.setAdapter(adapter);

        // Back button functionality
        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish(); // Return to previous activity
            }
        });

        // Placeholder for results button
        results.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(CalcListActivity.this, "Results feature not implemented yet.", Toast.LENGTH_SHORT).show();
                Intent intent = new Intent(CalcListActivity.this, Results.class);
                startActivity(intent);
            }
        });

        // Handle item clicks
        calcListJ.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                String selectedItem = itemList.get(position);
                Toast.makeText(CalcListActivity.this, "Selected: " + selectedItem + " in Calc List", Toast.LENGTH_SHORT).show();
            }
        });
    }


    // Load data from CalcList table
    private void loadCalcListTable(ArrayList<String> selectedItems) {
        itemList = new ArrayList<>();
        Cursor cursor = null;

        try {
            if (selectedItems != null && !selectedItems.isEmpty()) {
                // Create a dynamic query with placeholders for selected items
                StringBuilder placeholders = new StringBuilder();
                for (int i = 0; i < selectedItems.size(); i++) {
                    placeholders.append("?");
                    if (i < selectedItems.size() - 1) {
                        placeholders.append(",");
                    }
                }

                // Prepare the query
                String query = "SELECT * FROM CalcList WHERE ItemName IN (" + placeholders + ")";
                String[] args = selectedItems.toArray(new String[0]);

                // Execute the query
                cursor = db.rawQuery(query, args);

            } else {
                // Default behavior if no selected items are passed
                Toast.makeText(this, "No items selected!", Toast.LENGTH_SHORT).show();
                return;
            }

            // Process the results
            if (cursor != null && cursor.moveToFirst()) {
                do {
                    int itemNameColumnIndex = cursor.getColumnIndex("ItemName");
                    if (itemNameColumnIndex >= 0) {
                        String itemName = cursor.getString(itemNameColumnIndex);
                        itemList.add(itemName);
                    }
                } while (cursor.moveToNext());
            }

        } catch (SQLException e) {
            Toast.makeText(this, "Error loading data: " + e.getMessage(), Toast.LENGTH_LONG).show();
        } finally {
            if (cursor != null) cursor.close();
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        clearCalcList();
    }

    private void clearCalcList() {
        try {
            db.execSQL("DELETE FROM CalcList"); // Clear all rows from CalcList table
            Log.d("Database", "CalcList table cleared.");
        } catch (SQLException e) {
            Log.e("Database", "Error clearing CalcList: " + e.getMessage());
        }
    }
}

