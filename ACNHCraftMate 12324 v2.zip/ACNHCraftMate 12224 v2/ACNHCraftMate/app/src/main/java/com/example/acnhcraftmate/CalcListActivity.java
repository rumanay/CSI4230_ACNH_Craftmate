package com.example.acnhcraftmate;

import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;

import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;

public class CalcListActivity extends AppCompatActivity {

    //associate calcList with list view java object
    ListView calcListJ;
    Button back, results;
    private DBHelper myDbHelper;
    private SQLiteDatabase db;
    private ArrayAdapter<String> adapter;
    public ArrayList<String> itemList, calcItemsArray;




    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_calclist);

        calcListJ = findViewById(R.id.calcList);
        back = findViewById(R.id.backButton);
        results = findViewById(R.id.tempresultsButton);

        //add back button to main calculator activity
        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(CalcListActivity.this, CalculatorActivity.class);
                startActivity(intent);
            }
        });

        results.setOnClickListener(new View.OnClickListener()
           {

               @Override
               public void onClick(View v) {

                   //can create functions outside of onCreate to make the code look cleaner in the onClick function

                   //query each item in the calcList in the CraftTable to get the recipeID
                   //add all items in recipe to parallel arrays

                   //check if ingredientID is already in ingredientArray, if so get the position and add the total for that corresponding
                   //ingredient##Quantity to the sum already in that spot

                   //get how many unique ingredients, all ingredients, all quantities
                   //String searchQuery;
                   //Integer recipeUniqueNum;
                   //recipeUniqueNum = db.rawQuery("SELECT RecipeID FROM RecipeTable WHERE RecipeID=", new String[]{"%" + searchQuery + "%"});
                   //Integer recIngIDs[recipeUniqueNum]; //to get all recipe ingredient IDs
                   //Integer ingredientQuantities[recipeUniqueNum]; //to get all quantities for each ingredient in the recipe
                   //load all items into the created arrays
                   //may need to use ArrayLists instead of regular arrays

               }
           }


        );



    }//end on Create


    //get data from calculator activity
        //pass data from Calculator activity
        //add data to list


    //display list
    //load data function


    //add button to go back to CalculatorActivity to be able to add more items to the CalcList

    //add functionality to get results button
    //can be in new activity maybe DetailedListActivity or add a hidden textview/list view
    //and make visible once the results button is clicked

        //query each item in the calcList in the CraftTable to get the recipeID
        //add all items in recipe to parallel arrays

        //check if ingredientID is already in ingredientArray, if so get the position and add the total for that corresponding
        //ingredient##Quantity to the sum already in that spot

        // example: Flimsy Axe, Flimsy Net
        // get recipeID to be able to pull the recipe "card" from RecipeTable
            //String searchQuery;
            // //we want to get an exact match since the user is selecting only one item at a time to add to their temp list
            //recipeID = db.rawQuery("SELECT RecipeID FROM CraftTable WHERE ItemName=", new String[]{"%" + searchQuery + "%"});
            //recipeList[i] = recipeID; //may need to be an ArrayList recipeList<Integer>; to get the IDs


        //get how many unique ingredients, all ingredients, all quantities
            //String searchQuery;
            //Integer recipeUniqueNum;
            //recipeUniqueNum = db.rawQuery("SELECT RecipeID FROM RecipeTable WHERE RecipeID=", new String[]{"%" + searchQuery + "%"});
            //Integer recIngIDs[recipeUniqueNum]; //to get all recipe ingredient IDs
            //Integer ingredientQuantities[recipeUniqueNum]; //to get all quantities for each ingredient in the recipe
            //load all items into the created arrays
                //may need to use ArrayLists instead of regular arrays


    public void setCalcItemsArray(ArrayList<String> calcItemsArray) {
        this.calcItemsArray = calcItemsArray;
    }


}
